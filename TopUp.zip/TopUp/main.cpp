#include <iostream>
using namespace std;
class Stakeholder{
 private:
    const double CREDIT = 0.2;
    double balance = 0;
    int scanSuccessful;

 public:
   /* Stakeholder(double bal,int scan){
    this->balance = bal;
    this->scanSuccessful = scan;
    }*/
    Stakeholder(){};

   void setBalance(double balance){
       this->balance = balance;
    }

    double getBalance(){
        return this->balance;
    }
     double CreditClient(){
        cout<<"Enter 1 if scan was successful and 0 otherwise"<<endl;
        cin>>scanSuccessful;


        if(scanSuccessful==1){
            balance =balance + CREDIT;
            return balance;
            cout<<balance;
 }
       else{ return 0;}
}

};
int main()
{
   Stakeholder holder;
   holder.CreditClient();
   //holder
   return 0;

}
